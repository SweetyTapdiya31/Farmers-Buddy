export class FarmerLoginStatus {

    public message: string;
        public fullName: string;
    public farmerId:number;
   

}