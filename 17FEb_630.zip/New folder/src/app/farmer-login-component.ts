import { FarmerLogin } from './farmer-login';
import { Component } from '@angular/core';
import { FarmerLoginService } from './farmer-login-service';
import { ActivatedRoute, Router } from '@angular/router'
import { LoginStatus } from './loginstatus';
import { FarmerLoginStatus } from './farmerLoginSatus';
@Component({
selector :'farmerlogin',
templateUrl:'./farmer-login-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class FarmerLoginComponent{
    farmerlogin: FarmerLogin = new FarmerLogin();
   
    email:string;
    password:string;
    request: string;
    submitted: boolean;
    response: FarmerLoginStatus;
   
    constructor(private ms: FarmerLoginService ,private router :Router){

    }
 add(mform){
    this.ms.sendToServer(this.farmerlogin)
    .subscribe(data => {
        this.response=data;

        if(this.response.message == "success"){
            sessionStorage.setItem("fullName", this.response.fullName);
           
            sessionStorage.setItem("farmerId", ""+this.response.farmerId);
            this.router.navigate(['./farmerDashboard']);
        }
        else{
            this.farmerlogin.email="";
           this.farmerlogin.password="";
           alert("Please check ur email id and password");
            this.router.navigate(['./farmerlogin']);
           
        }

              
            }
        );
    }
   
    
    

   

}