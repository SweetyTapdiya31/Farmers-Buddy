export class Bid {
    public bidderId: string;
    public cropId: number;
    public bidAmount: number;
}