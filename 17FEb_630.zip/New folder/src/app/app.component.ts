import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  template:`
  <!--<add-bidder></add-bidder>-->
    <!--<login></login>-->
    <!--<add-farmer></add-farmer>-->
    <!--<farmerlogin></farmerlogin>-->
   <!--<bidder-dashboard></bidder-dashboard>-->
   
   <!--<admin-login></admin-login>-->
    <home></home>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular';
}
