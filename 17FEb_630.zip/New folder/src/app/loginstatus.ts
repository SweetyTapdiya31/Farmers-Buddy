export class LoginStatus {

    public message: string;
    public bidderId: number;
    public fullName: string;
    public farmerId:number;
   

}