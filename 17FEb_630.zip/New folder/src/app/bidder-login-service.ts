import { BidderLogin } from './bidder-login';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { BidderLoginComponent } from './bidder-login-component';
import { Observable } from 'rxjs';
import { LoginStatus } from './loginstatus';

@Injectable() //Dependency Injection
export class BidderLoginService{
    //This class will talk to server

    constructor(private http:HttpClient)
    {
            
    }
	 sendToServer(login: BidderLogin) : Observable<LoginStatus> {
        //Send data to server in JSON form
        let url = "http://localhost:8151/bidderlogin/verifybidder";
        return this.http.post<LoginStatus>(url, login);
    } 
    
   
}