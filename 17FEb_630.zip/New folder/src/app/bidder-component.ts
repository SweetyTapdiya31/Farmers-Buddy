import { Bidder } from './bidder';
import { Component } from '@angular/core';
import { BidderService } from './bidder-service';
import { Router } from '@angular/router';
@Component({
selector :'add-bidder',
templateUrl:'./bidder-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class BidderComponent{
    bidder: Bidder = new Bidder();
    response: string;
    confirmpass:String;
    array={ password:"" , msg: ""};
    constructor(private ms: BidderService ,private router:Router){

    }

    keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
          event.preventDefault();
        }
      }

     
   add(mform){
    let confirm=true;

    if(this.bidder.confirmPassword != this.bidder.password){
        confirm=false;
        this.array['password'] = "Password does not match";
    }
   if(confirm){
    
        this.ms.sendToServer(this.bidder).subscribe(
            data => {
               
                this.response= data.toString();
            var check=this.response;
    
            if(check == "true"){
                alert("Thank You for Registering");
                
                this.router.navigate(['./login']);
            }
            }
        );
    } 

   

}
}