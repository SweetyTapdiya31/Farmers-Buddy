
import { Component } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router'
import { AdminLogin } from './adminLogin';
import { AdminLoginService } from './adminLoginSevice';
@Component({
selector :'admin-login',
templateUrl:'./AdminLogin.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class AdminLoginComponent{
    login: AdminLogin = new AdminLogin();
    response: AdminLogin;
  
    constructor(private ms: AdminLoginService ,private router:Router){

    }
   add(mform){
    this.ms.sendToServer(this.login)
      
    .subscribe(data => { 
        this.response= data;
        if(this.response.message == "success"){
            sessionStorage.setItem("emailId", this.response.emailId);
            
            this.router.navigate(['./admin-dashboard']);
        }
        else{
            this.login.emailId="";
           this.login.password="";
           alert("Please check ur email id and password");
            this.router.navigate(['./admin-login']);
          
            
        }
    }
        );
    }
    
    

   

}