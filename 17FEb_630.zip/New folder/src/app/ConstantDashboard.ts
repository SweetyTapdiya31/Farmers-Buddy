import { Component } from '@angular/core';


@Component({
    selector: 'constant-Dashboard',
    templateUrl: './dashboard-constant.html',
    //styleUrls: ['./farmerDashboard.component.css']

    
})

export class ConstantDashboard{
    constructor(){

    }
    
}