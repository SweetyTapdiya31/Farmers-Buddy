import {Component} from '@angular/core'

export class BidderLogin{

    constructor(
        public email?:string,
        public password?:string,
        
         ){

         }
}