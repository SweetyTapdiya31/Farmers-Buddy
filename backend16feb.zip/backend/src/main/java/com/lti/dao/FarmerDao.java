package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.Farmer;
import com.lti.entity.FarmerCropSell;
import com.lti.entity.Bidder;
import com.lti.entity.BiddingCrop;

@Repository

public class FarmerDao {
	@PersistenceContext
	private EntityManager entityManager;
	@Transactional
	public void add(Farmer farmer) {
		entityManager.merge(farmer);
	}
	
	@Transactional
	public void addCrop(FarmerCropSell farmerCrop) {
			entityManager.merge(farmerCrop);
	}
	
	@Transactional
	public Farmer fetchFarmer(int id)
	{
	return entityManager.find(Farmer.class, id);	
	}

	@Transactional
	public FarmerCropSell fetchFarmerCrop(int cropId)
	{
	return entityManager.find(FarmerCropSell.class, cropId);	
	}

@Transactional
	public List<FarmerCropSell> fetchAll() {
		Query q = entityManager.createQuery("select obj from FarmerCropSell as obj ");
		
		return q.getResultList();

	}
	


@Transactional
	public void addBid(BiddingCrop biddingCrop) {
		entityManager.merge(biddingCrop);
	}
	
@Transactional
public Double addCurrentBid(int crop) {
	Query q= entityManager.createQuery(" select max(obj.bidAmount) from BiddingCrop obj where obj.farmerCropSell.cropId=?1");
	q.setParameter(1, crop);
	//System.out.println(q);
	return (Double)q.getSingleResult();
	
}

public void insertFarmerSell(int cropId) {
	Query q=entityManager.createQuery("insert into FarmerCropSell(currentBid)   (select b.bidAmount from BiddingCrop b) where cropId=?1");
	q.setParameter(1, cropId);
	q.executeUpdate();
}


}
