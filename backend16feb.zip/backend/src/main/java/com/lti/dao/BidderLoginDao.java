package com.lti.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.Bidder;
import com.lti.entity.Farmer;


@Repository  

public class BidderLoginDao {
	@PersistenceContext
	private EntityManager entitymanager;
	
	
	@Transactional
	public Bidder fetchBidder(String emailId,String password){
		Query q= entitymanager.createQuery("from Bidder as obj where obj.emailId=?1 and obj.password=?2");
		q.setParameter(1,emailId);
		q.setParameter(2,password);
		return (Bidder) q.getSingleResult();
	}

}
