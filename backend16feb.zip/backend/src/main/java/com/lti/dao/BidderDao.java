package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.Bidder;


@Repository  
public class BidderDao {
	
	@PersistenceContext
	private EntityManager entitymanager;
	
	@Transactional
	public void add(Bidder bidder)
	{
		entitymanager.persist(bidder);
		
	}
	
	@Transactional
	public Bidder fetch(int id)
{
return entitymanager.find(Bidder.class, id);	
}
	

}
