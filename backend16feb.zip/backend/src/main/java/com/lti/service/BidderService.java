package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.BidderDao;
import com.lti.entity.Bidder;

import org.springframework.beans.factory.annotation.Autowired;
@Service
public class BidderService {
	@Autowired
	private BidderDao bidderDao;
	
	@Transactional
	public void add(Bidder bidder) {
		bidderDao.add(bidder);

	}
	
	public Bidder fetch(int id) {
		return bidderDao.fetch(id);
	}


}
