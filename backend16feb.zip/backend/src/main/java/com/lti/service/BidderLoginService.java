
package com.lti.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.BidderLoginDao;
import com.lti.dto.LoginDto;
import com.lti.dto.LoginStatus;
import com.lti.entity.Bidder;
@Service
public class BidderLoginService {
	
	@Autowired
	private BidderLoginDao bidderLoginDao;
	
	
	@Transactional
	public LoginStatus verifyBidder(LoginDto loginDto) {
		String email=loginDto.getEmail();
		String password=loginDto.getPassword();
		LoginStatus status = new LoginStatus();
		
		try {
			Bidder bidder =bidderLoginDao.fetchBidder(email,password);
			status.setMessage("success");
			status.setBidderId(bidder.getId());
			status.setFullName(bidder.getFullName());
		}
		catch (Exception e) {
			status.setMessage("error");
			e.printStackTrace();
		}
		return status;
	}

}
