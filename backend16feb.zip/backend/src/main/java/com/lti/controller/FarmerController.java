package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.BiddingDto;
import com.lti.entity.BiddingCrop;
import com.lti.entity.Farmer;
import com.lti.entity.FarmerCropSell;
import com.lti.service.FarmerService;

@RestController
@CrossOrigin

public class FarmerController {
	@Autowired
	private FarmerService farmerService;
	
	@RequestMapping(path="/farmer/add", method=RequestMethod.POST)
	@CrossOrigin
	public boolean add(@RequestBody Farmer farmer) {
		farmerService.add(farmer);
		return true;
	}
	
	@RequestMapping(path="/farmerCrop/add", method=RequestMethod.POST)
	@CrossOrigin
	public String addCrop(@RequestBody FarmerCropSell farmerCrop) {
		farmerService.addCrop(farmerCrop);
		return "{\"status\" : \" Your records have been inserted Successfully!!\"}";
	}
	

	@RequestMapping(path = "bidder/biddingcrop",method = RequestMethod.GET)
	@CrossOrigin
	public List<FarmerCropSell> sendData() {
		return farmerService.fetchAll();
	}
	
	@RequestMapping(path = "/biddingCrop/add", method = RequestMethod.POST)
	public String addCrop(@RequestBody BiddingDto biddingDto) {
		farmerService.addBid(biddingDto);
		return "{\"status\" : \" Bidding Was Successfull!!\"}";
	}

}
