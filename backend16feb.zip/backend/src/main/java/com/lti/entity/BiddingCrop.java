package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class BiddingCrop {

	@Id
	@GeneratedValue
	private int bidId;
	
	private double bidAmount;
	
	@ManyToOne
	@JoinColumn(name = "cropId")
	@JsonIgnore
	private FarmerCropSell farmerCropSell;
	
	@ManyToOne
	@JoinColumn(name = "bidder_id")
	@JsonIgnore
	private Bidder bidder;
	
	public Bidder getBidder() {
		return bidder;
	}
	public void setBidder(Bidder bidder) {
		this.bidder = bidder;
	}
	public int getBidId() {
		return bidId;
	}
	public void setBidId(int bidId) {
		this.bidId = bidId;
	}
	public double getBidAmount() {
		return bidAmount;
	}
	public void setBidAmount(double bidAmount) {
		this.bidAmount = bidAmount;
	}
	public FarmerCropSell getFarmerCropSell() {
		return farmerCropSell;
	}
	public void setFarmerCropSell(FarmerCropSell farmerCropSell) {
		this.farmerCropSell = farmerCropSell;
	}

	
}
