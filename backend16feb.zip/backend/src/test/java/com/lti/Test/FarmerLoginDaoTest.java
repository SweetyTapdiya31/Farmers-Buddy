package com.lti.Test;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.BidderDao;
import com.lti.dao.BidderLoginDao;
import com.lti.dao.FarmerLoginDao;
import com.lti.demo.DemoApplication;
import com.lti.entity.Bidder;
import com.lti.entity.Farmer;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class FarmerLoginDaoTest {
	@Autowired
	private FarmerLoginDao farmerLoginDao;
	
	
	@Transactional
	@Test
	public void loginVerify() {
		Farmer f=farmerLoginDao.fetchFarmer("shweta.durkellu6@gmail.com","aa");
		
	
       
        
}

}

