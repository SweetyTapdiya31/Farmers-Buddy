import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SellRequest } from './SellRequest';



@Injectable()   

export class SellRequestService {

    
    constructor(private http:HttpClient){

    }
    sendToServer(url,user:SellRequest) {
        
        return this.http.post(url,user)
        } 
             
        }