import { BidderDashboard } from './bidder-dashboard';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable() //Dependency Injection
export class BidderDashboardService{
    //This class will talk to server

    constructor(private http:HttpClient)
    {
            
    }
    retrieveFromServer(url:string): Observable<BidderDashboard[]>
    {
       return this.http.get<BidderDashboard[]>(url)
    } 
    

}