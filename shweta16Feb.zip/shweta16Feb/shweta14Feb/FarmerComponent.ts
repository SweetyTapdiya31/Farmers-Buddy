import { Component } from '@angular/core';
import { FarmerService } from 'FarmerService';
import { Farmer } from 'Farmer';
import { stringify } from '@angular/core/src/util';

@Component({
selector :'add-farmer',
templateUrl:'./farmer-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class FarmerComponent{
    farmer:Farmer = new Farmer();
    response: string;
    confirmpass:String;
    array={ password:"" , msg: ""};
    constructor(private fs: FarmerService){
        
    }
    keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
          event.preventDefault();
        }
      }
   add(mform){
       let confirm=true;

       if(this.confirmpass != this.farmer.password){
           confirm=false;
           this.array['password'] = "Password does not match";
       }
      if(confirm){
       
        this.fs.sendToServer(this.farmer).subscribe(
            data => {
                //Take the response from server and storing in string variable
                this.response = data['status'];
            }
        
        );
       }
        } 

   

}