import {Component} from '@angular/core'

export class SellRequest{

    constructor(
       public currentBid?:number,
        public cropType?:string,
        public  cropName?:string,
        public fertilizerType?:string,
        public quantity?:number,
        public priceperquintal?:number,
        public soilpHCertificate?:string,
        public farmer?: Map<string,string>
         ){

         }
}