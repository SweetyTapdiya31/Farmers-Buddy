import {Component} from '@angular/core'

export class AdminLogin{

    constructor(
        public emailId?:string,
        public password?:string
         ){

         }
}