import {Component, Injectable} from '@angular/core'

import { OnInit } from '@angular/core';
import { BidderDashboardService } from './bidder-dashboard-service';
import { BidderDashboard } from './bidder-dashboard';
import { Router } from '@angular/router';
import { Bid } from './bid';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
    selector: 'bidder-dashboard',
    templateUrl: './bidder-dashboard-component.html'
})

export class BidderDashboardComponent implements OnInit
{
    dashboard: BidderDashboard[];
    dashboard1:BidderDashboard;
    response: any;
    fullName: string;
    bid: Bid = new Bid();

    constructor(private bds: BidderDashboardService ,private router:Router){

    }
    ngOnInit(){
        this.fullName = sessionStorage.getItem("fullName");
        this.loadCrops();
     }
    loadCrops()
    {
        let url = "http://localhost:8150/bidder/biddingcrop";
        this.bds.retrieveFromServer(url).subscribe(data=>{
            this.dashboard=data;
            console.log("Dashboard data " + JSON.stringify(this.dashboard));
        });
    }
    add(mform)
    {
        this.bid.bidderId = sessionStorage.getItem("bidderId");
         
            this.bds.sendToServer(this.bid).subscribe(data => { 
                this.response = data['status'];
 
      });
  }

    
        }
  
    
