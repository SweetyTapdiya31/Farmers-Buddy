import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BidderService } from 'src/app/bidder-service';

import { BidderLoginService } from 'src/app/bidder-login-service';
import { FarmerService } from 'src/app/FarmerService';
import { FarmerComponent } from 'src/app/FarmerComponent';

import { FarmerLoginService } from 'src/app/farmer-login-service';
 import {RouterModule, Router, RouterOutlet} from '@angular/router';
import { HomeComponent } from 'src/app/home-component';

import { BidderDashboardService } from 'src/app/bidder-dashboard-service';
import { BidderDashboardComponent } from 'src/app/bidder-dashboard-component';
import { BidderComponent } from './bidder-component';
import { BidderLoginComponent } from './bidder-login-component';
import { FarmerLoginComponent } from './farmer-login-component';
import { FarmerDashboard } from './farmerDashboard.component';
import { AppRoutingModule } from './app-routing.module';
import { SellRequestcomponent } from './SellRequest.component';
import { SellRequestService } from './SellRequestService';
import { SoldHistorycomponent } from './soldhistory.component';
import { ConstantDashboard } from './ConstantDashboard';
import { AdminLoginComponent } from './adminLogin.component';
import { AdminLoginService } from './adminLoginSevice';





@NgModule({
  declarations: [
    AppComponent,
    BidderComponent,
    BidderLoginComponent,
    FarmerComponent,
    FarmerLoginComponent,
    HomeComponent,
   BidderDashboardComponent,
    FarmerDashboard,
    SellRequestcomponent,
    SoldHistorycomponent,
    ConstantDashboard,
    AdminLoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
    
    
  ],
  providers: [BidderService,BidderLoginService,HttpClient,FarmerService,FarmerLoginService,BidderDashboardService,SellRequestService,AdminLoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }