
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import { Observable } from 'rxjs';
import { AdminLogin } from './adminLogin';

@Injectable() //Dependency Injection
export class AdminLoginService{
    //This class will talk to server

    constructor(private http:HttpClient)
    {
            
    }
	 sendToServer(login: AdminLogin){
        //Send data to server in JSON form
        let url = "http://localhost:8150/login/admin";
        return this.http.post(url, login);
    } 
    
   
}