
import { Component } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router'
import { AdminLogin } from './adminLogin';
import { AdminLoginService } from './adminLoginSevice';
@Component({
selector :'admin-login',
templateUrl:'./bidder-login-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class AdminLoginComponent{
    login: AdminLogin = new AdminLogin();
    response: string;
  
    constructor(private ms: AdminLoginService ,private router:Router){

    }
   add(mform){
        this.ms.sendToServer(this.login)
        .subscribe(data => { 
            this.response= data.toString();
            var check=this.response;
   
            if(check == "true"){
                
                this.router.navigate(['./admin-dashboard']);
            }
            else{
                this.login.emailId="";
               this.login.password="";
                this.router.navigate(['./admin-login']);
                alert("Please check ur email id and password");
                
            }
        }
        );
    }
    
    

   

}