import {Component} from '@angular/core'

export class Login{

    constructor(
        public emailId?:string,
        public password?:string,
        
         ){

         }
}