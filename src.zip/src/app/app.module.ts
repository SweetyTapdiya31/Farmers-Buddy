import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BidderComponent } from 'src/bidder-component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BidderService } from 'src/bidder-service';
import { LoginComponent } from 'src/login-component';
import { LoginService } from 'src/login-service';

@NgModule({
  declarations: [
    AppComponent,
    BidderComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BidderService,LoginService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }