import { Login } from './login';
import { Component } from '@angular/core';
import { LoginService } from './login-service';
@Component({
selector :'login',
templateUrl:'./login-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class LoginComponent{
    login: Login = new Login();
    response: string;
    constructor(private ms: LoginService){

    }
   add(mform){
        this.ms.sendToServer(this.login).subscribe(
            data => {
                //Take the response from server and storing in string variable
                this.response = data['status'];
            }
        );
    }
    
    

   

}