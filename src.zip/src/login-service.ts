import { Login } from './login';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { LoginComponent } from './login-component';
import { Observable } from 'rxjs';

@Injectable() //Dependency Injection
export class LoginService{
    //This class will talk to server

    constructor(private http:HttpClient)
    {
            
    }
	 sendToServer(login: Login){
        //Send data to server in JSON form
        let url = "http://localhost:8150/login/add";
        return this.http.post(url, login);
    } 
    

}